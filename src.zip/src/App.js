import React from 'react';

import './App.css';
import Navbar from "./components/navbar/navbar.component.js";

function App() {
  return (
    <div className="App">
    <Navbar></Navbar>
    </div>
  );
}

export default App;
