import React from 'react';

import "./navbar.component.css";
import hpLogo from "../../assets/hpLogo.png";
import calender from "../../assets/calender.svg";
import Dropdown from '../DropDown/dropdown';
import BreadCum from '../BreadCum/BreadCum'
const NavBar = (props) => {

    return(

        <div className="navbar">
            <div className="header">
                <img src={hpLogo}></img>
                <p>Digital Shelf</p>
            
                <ul>
                <li>Overview</li>
                <li>Competitor Analysis</li>
                <li>Promotion Analysis</li>
                </ul>

            </div>
            <div className="navbarContent">
            <div id="selectDates">
                        <img src={calender}></img>
                        
                        <Dropdown></Dropdown>
                        <Dropdown></Dropdown>
                    </div>
               <BreadCum></BreadCum>
            </div>

        </div>
    );

}
export default NavBar;