import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';

const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: 100,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
  }));

function Dropdown() {
    const [age, setAge] = React.useState('');
    const  classes = useStyles();


    const handleChange = (event) => {
        setAge(event.target.value);
      };

        return(
            <FormControl className={classes.formControl}>
            <InputLabel id="simplevariable">Weekly</InputLabel>
            <Select
              labelId="demo-simple-select-helper-label"
              id="demo-simple-select-helper"
              value={age}
              onChange={handleChange}
            >
              <MenuItem value="">
                <em>None</em>
              </MenuItem>
              <MenuItem value={1}>Week1</MenuItem>
              <MenuItem value={2}>Week2</MenuItem>
              <MenuItem value={3}>Week3</MenuItem>
              <MenuItem value={4}>Week4</MenuItem>
            </Select>
            <FormHelperText>Compared to previous period</FormHelperText>
          </FormControl>
    
        );
    }
       

    export default Dropdown;

